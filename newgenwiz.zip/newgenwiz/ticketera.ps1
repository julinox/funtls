function New-Ticket {
    return [PSCustomObject]@{
        origin        = ""
        node          = ""
        resource      = ""
        message_key   = ""
        time_of_event = ""
        metric_name   = ""
        description   = ""
        severety      = ""
        resource_id   = ""
    }
}

function New-AzResource {
    return [pscustomobject]@{
        SubscriptionId = ''
        ResourceGroup  = ''
        Provider       = ''
        ResourceType   = ''
        ResourceName   = ''
        RawId          = ''
    }
}

function Parse-ResourceId {
    param (
        [Parameter(Mandatory)]
        [string]$ResourceId
    )

    $parts = $ResourceId -split "/"
    if ($parts.Count -lt 9 -or $parts[1].ToLower() -ne 'subscriptions') {
        return $null
    }

    $resource = New-AzResource
    $resource.RawId = $ResourceId
    for ($i = 1; $i -lt $parts.Count - 1; $i += 2) {
        $key = $parts[$i].ToLower()
        $value = $parts[$i + 1]

        switch ($key) {
            "subscriptions"   { $resource.SubscriptionId = $value }
            "resourcegroups"  { $resource.ResourceGroup  = $value }
            "providers"       { $resource.Provider       = $value }
        }
    }

    $resource.ResourceType = $parts[-2]
    $resource.ResourceName = $parts[-1]
    return $resource
}

function Configure-Ticket {
    param(
        [Parameter(Mandatory = $true)]
        [object]$ticket,

        [Parameter(Mandatory = $true)]
        [object]$reqBody
    )

    try {
        # Validar estructura mínima
        if (-not $reqBody.data -or -not $reqBody.data.essentials) {
            return "Faltan campos esenciales en el JSON (data.essentials)"
        }

        $ess = $reqBody.data.essentials

        # Validar y extraer resourceId
        if (-not $ess.alertTargetIDs -or $ess.alertTargetIDs.Count -eq 0) {
            return "No se encontró alertTargetIDs"
        }

        $resourceId = $ess.alertTargetIDs[0]
        $parts = $resourceId -split "/"
        if ($parts.Length -lt 9) {
            return "Formato inválido de resourceId: $resourceId"
        }

        # Cargar campos
        $ticket.origin        = "Azure Monitor"
        $ticket.node          = $parts[-1]
        $ticket.resource      = $parts[-2]
        $ticket.message_key   = $ess.alertRule
        $ticket.metric_name   = $ess.signalType
        $ticket.severety      = $ess.severity
        $ticket.time_of_event = $ess.firedDateTime
        $ticket.resource_id   = $resourceId

        return "" 
    } catch {
        return "Excepción en ConfigureTicket: $_"
    }
}

function Build-TicketDescription {
    param(
        [Parameter(Mandatory = $true)]
        [object]$ticket
    )

    try {

        $rid = Parse-ResourceId $ticket.resource_id
        if ($rid -eq $null) {
            return "Azure ResourceID invalido: $($ticket.resource_id)"
        }

        return "NARANJAS"

    } catch {
        return "Error generando descripción: $_"
    }
}

function Print-Ticket {
    param (
        [Parameter(Mandatory = $true)]
        [pscustomobject]$Ticket
    )

    $props = $Ticket | Get-Member -MemberType NoteProperty | Select-Object -ExpandProperty Name
    foreach ($key in $props) {
        $value = $Ticket.$key
        Log-Message "$key = $value" "INFO"
    }
}

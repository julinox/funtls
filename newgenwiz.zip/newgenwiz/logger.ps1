# Simulacion de un logger. 
# LOGLEVEL: Determina el level de escritura, default toma INFO (de no existir la variable).
# LOGSTDOUT: Determina donde escribir, default toma stdout (Write-Host)
# LOGHEADER: Determina si agregar formato al mensaje
function Log-Message {
    param(
        [string]$Message,
        [string]$Level
    )

    if (-not $Message) {
        throw "Param 'Message' is required for 'WriteHost'"
    }

    if (-not $Level) {
        $Level = "INFO"
    }

    $loglvl = "INFO"
    if (-not [string]::IsNullOrEmpty($LOGLEVEL)) {
        $aux = LevelToNumber $LOGLEVEL
        if ($aux -ge 0) {
            $loglvl = $LOGLEVEL
        }
    }

    $aux1 = LevelToNumber -Level $Level
    $aux2 = LevelToNumber -Level $loglvl
    if ($aux1 -lt $aux2) {
        return
    }

    $timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    $logMessage = "$timestamp [$Level] $Message"
    if ($LOGHEADER -and $LOGHEADER.ToString().ToLower() -eq "true") {
        WriteStdOut "$logMessage"
    } else {
        Write-Host "$Message"
    }
}

# Helper para WriteHost()
function LevelToNumber {
    param(
        [string]$Level
    )

    switch ($Level.ToLower()) {
        "debug"   { return 0 }
        "info"    { return 1 }
        "warn"    { return 2 }
        "error"   { return 3 }
        "fatal"   { return 4 }
        default   { return -1 }
    }
}

# Helper para WriteHost()
function WriteStdOut {

    param(
        [string]$Message
    )

    $out = "stdout"
    if (Get-Variable -Name "LOGSTDOUT" -Scope "Script" -ErrorAction SilentlyContinue) {
        $out = $LOGSTDOUT
    }

    if ($out -eq "stdout") {
        Write-Host "$Message"
    } else {
        Add-Content -Path $out -Value $Message
    }
}

using namespace System.Net
param($Request, $TriggerMetadata)

# Set-StrictMode -Version Latest
# Imports
. .\logger.ps1
. .\ticketera.ps1
. ..\genwizard\src\vars.ps1

function Main {

    try {
        if ($Request.Body -is [System.Collections.Hashtable]) {
            $reqBody = $Request.Body
        } else {
            $reqBody = $Request.Body | ConvertFrom-Json
        }

        $condition = $reqBody.data.essentials.monitorCondition

    } catch {
        Write-Host "$($_.Exception.Message)" "ERROR"
    }

    $newTicket = New-Ticket
    $err = Configure-Ticket $newTicket $reqBody
    if ($err -ne "") {
        Log-Message "Configure-Ticket: $err" "ERROR"
        return
    }

    Print-Ticket $newTicket
    #$pp = Build-TicketDescription $newTicket
    #Write-Host $pp
}

Main